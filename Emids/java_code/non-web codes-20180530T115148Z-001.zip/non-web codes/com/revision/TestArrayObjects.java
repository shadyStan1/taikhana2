package com.revision;
public class TestArrayObjects {
public static void main(String[] args) {
	String[] s = {"da","baegd","bfsegdv"};
	String []s1 = s;
	s1[0] = "abdsh";
	System.out.println(s[0]);
}
}
