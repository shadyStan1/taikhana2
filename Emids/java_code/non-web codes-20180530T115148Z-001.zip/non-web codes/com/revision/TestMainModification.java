package com.revision;
public class TestMainModification {
final synchronized strictfp public void main(String args) {
	
}
}
