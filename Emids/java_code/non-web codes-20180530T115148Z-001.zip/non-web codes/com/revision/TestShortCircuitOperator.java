package com.revision;

public class TestShortCircuitOperator {

	public static void main(String[] args) {
		int x = 10;
		int y = 20;
		
		if(x > y || x == 10){
			System.out.println("vbdrfvdbh");
		}
	}
}
