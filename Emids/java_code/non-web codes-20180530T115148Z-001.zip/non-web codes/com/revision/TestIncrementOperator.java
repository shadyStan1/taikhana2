package com.revision;

public class TestIncrementOperator {
public static void main(String[] args) {
	int n = 10;
	System.out.println("value of n = ");
}
}
