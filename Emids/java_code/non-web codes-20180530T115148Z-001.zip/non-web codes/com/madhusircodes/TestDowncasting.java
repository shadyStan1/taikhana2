package com.madhusircodes;
public class TestDowncasting {
public static void main(String[] args) {
	Object o = new Object();
	String s = (String) o;
}
}
