package com.hackerrank;

public class PrintNumInWords {
public static void main(String[] args) {
	System.out.println(123%10000000);
}
}
