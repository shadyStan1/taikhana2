package com.hackerrank;
import java.util.Scanner;
public class ScannerClassTest {
public static void main(String[] args) {
	
	String s = "nsehfvbrbh brshsb bfsf b";
	System.out.printf(s+"\n");
	
}
}
