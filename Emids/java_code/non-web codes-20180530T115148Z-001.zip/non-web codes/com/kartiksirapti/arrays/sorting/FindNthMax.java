package com.kartiksirapti.arrays.sorting;
public class FindNthMax {
public static void main(String[] args) {
	int []ar = {2,3,5,1,5,7,35,22,11};
	int[] rearr = BubbleSort.sort(ar);
	System.out.println(rearr);
}
}
