package com.kartiksirapti.arrays;
public class FindFirstThree {
	public static void main(String[] args) {
		int[] ar = {12,5,48,3,78};
		findTwoMax(ar);
	}
	public static void findTwoMax(int[] num)
	{

	}
	}
