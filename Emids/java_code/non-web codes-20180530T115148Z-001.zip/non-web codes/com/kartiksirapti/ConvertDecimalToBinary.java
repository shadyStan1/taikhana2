package com.kartiksirapti;
public class ConvertDecimalToBinary {
public static void main(String[] args) {
//	String final = convert(12);
//	System.out.println(final);
//}
////
//public static String convert(int num)
//{
//	int q = num;
//	int[] rem = {};
//	while(q >= 1)
//	{
//		
//	}
//	return rem;
}
}
