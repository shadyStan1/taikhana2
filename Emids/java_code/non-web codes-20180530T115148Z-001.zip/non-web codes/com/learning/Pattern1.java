package com.learning;
public class Pattern1 {
public static void main(String[] args) {
	int n  = 5;
	for (int i = 0; i < n; i++) {
	System.out.println("sgrg");
	}
}
}
