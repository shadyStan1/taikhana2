package com.jdbc;

public class Test {
	static int x = 10;
	{
		x = 10 +1 ;
	}
	int y = 10;
	public static void main(String[] args){
	
	}
}
