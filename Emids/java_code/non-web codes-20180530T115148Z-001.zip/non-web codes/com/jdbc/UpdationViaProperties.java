package com.jdbc;

public class UpdationViaProperties {

}
