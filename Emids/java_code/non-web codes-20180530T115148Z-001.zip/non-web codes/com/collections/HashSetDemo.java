package com.collections;

import java.util.*;

public class HashSetDemo {
public static void main(String[] args) {
	TreeSet hs = new TreeSet();
	hs.add(1);
	hs.add(1);
	hs.add(2);
	System.out.println(hs);
}
}
